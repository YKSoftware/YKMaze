﻿namespace YKMaze.Views
{
    using YKToolkit.Controls;

    /// <summary>
    /// DebugView.xaml の相互作用ロジック
    /// </summary>
    public partial class DebugView : Window
    {
        public DebugView()
        {
            InitializeComponent();
        }
    }
}
