﻿namespace YKMaze.Views
{
    using YKToolkit.Controls;

    /// <summary>
    /// VersionView.xaml の相互作用ロジック
    /// </summary>
    public partial class VersionView : Window
    {
        public VersionView()
        {
            InitializeComponent();
        }
    }
}
